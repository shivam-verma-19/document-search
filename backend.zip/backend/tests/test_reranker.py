"""
Tests for reranker.py — cross-encoder reranker with LLM scoring and
keyword-overlap fallback.
"""

import types
from unittest.mock import MagicMock, patch

import pytest


def _make_doc(text: str, doc_id: str = ""):
    from backend.app.document_repository import SearchDocument

    return SearchDocument(page_content=text, doc_id=doc_id or text[:20])


class TestKeywordFallback:
    def test_returns_sorted_best_first(self):
        from backend.app.reranker import rerank

        docs = [
            _make_doc("unrelated content about bananas"),
            _make_doc("python machine learning python python"),
            _make_doc("some python code"),
        ]
        result = rerank("python", docs, use_llm=False)
        assert result[0].page_content == "python machine learning python python"

    def test_empty_returns_empty(self):
        from backend.app.reranker import rerank

        assert rerank("query", [], use_llm=False) == []

    def test_single_doc_returned(self):
        from backend.app.reranker import rerank

        doc = _make_doc("hello world")
        assert rerank("hello", [doc], use_llm=False) == [doc]

    def test_no_overlap_still_returns_doc(self):
        from backend.app.reranker import rerank

        doc = _make_doc("quantum physics banana")
        result = rerank("unrelated query xyz", [doc], use_llm=False)
        assert len(result) == 1

    def test_length_bonus_affects_score(self):
        from backend.app.reranker import _keyword_score

        short = "python"
        long_doc = " ".join(["python"] * 200)
        assert _keyword_score("python", long_doc) > _keyword_score("python", short)


class TestLLMReranker:
    def test_llm_score_used_when_use_llm_true(self):
        from backend.app.reranker import rerank

        scores = iter([0.9, 0.1, 0.5])
        with patch(
            "backend.app.reranker._llm_score", side_effect=lambda q, d: next(scores)
        ):
            docs = [_make_doc(f"doc{i}") for i in range(3)]
            result = rerank("query", docs, use_llm=True)
        assert result[0].page_content == "doc0"  # scored 0.9
        assert result[1].page_content == "doc2"  # scored 0.5
        assert result[2].page_content == "doc1"  # scored 0.1

    def test_llm_score_failure_falls_back_to_keyword(self):
        from backend.app.reranker import rerank

        with patch(
            "backend.app.reranker._llm_score", side_effect=Exception("api down")
        ):
            docs = [_make_doc("python ml tutorial"), _make_doc("bananas")]
            # Should not raise — falls back gracefully
            result = rerank("python", docs, use_llm=True)
        assert len(result) == 2

    def test_score_threshold_filters_low_docs(self, monkeypatch):
        import backend.app.reranker as rr

        monkeypatch.setattr(rr, "RERANK_SCORE_THRESHOLD", 0.5)
        scores = iter([0.9, 0.2, 0.8])
        with patch(
            "backend.app.reranker._llm_score", side_effect=lambda q, d: next(scores)
        ):
            docs = [_make_doc(f"doc{i}") for i in range(3)]
            result = rr.rerank("query", docs, use_llm=True)
        # doc1 (0.2) should be filtered
        contents = [d.page_content for d in result]
        assert "doc1" not in contents
        assert "doc0" in contents
        assert "doc2" in contents

    def test_max_chunks_cap_respected(self, monkeypatch):
        import backend.app.reranker as rr

        monkeypatch.setattr(rr, "RERANK_MAX_CHUNKS", 2)
        call_count = {"n": 0}

        def counting_score(q, d):
            call_count["n"] += 1
            return 0.5

        with patch("backend.app.reranker._llm_score", side_effect=counting_score):
            docs = [_make_doc(f"doc{i}") for i in range(5)]
            rr.rerank("query", docs, use_llm=True)
        assert call_count["n"] == 2  # only first 2 scored via LLM

    def test_remainder_appended_after_scored(self, monkeypatch):
        import backend.app.reranker as rr

        monkeypatch.setattr(rr, "RERANK_MAX_CHUNKS", 2)
        with patch("backend.app.reranker._llm_score", return_value=0.5):
            docs = [_make_doc(f"doc{i}") for i in range(4)]
            result = rr.rerank("query", docs, use_llm=True)
        # All 4 docs should be present (2 scored + 2 remainder)
        assert len(result) == 4
